document.querySelector(".buy-me-coffee").addEventListener("click" , function(e){
    var target = document.querySelector(".coffee-options")
    target.setAttribute("style" , "display:flex;");
})
