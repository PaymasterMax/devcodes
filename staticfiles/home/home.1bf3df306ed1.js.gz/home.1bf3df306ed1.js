document.querySelector(".buy-me-coffee").addEventListener("click" , function(e){
    var target = document.querySelector(".coffee-options")
    if (getComputedStyle(target).display=="none") {
    }
});
document.querySelector(".close").addEventListener("click" , function(e){
  
})
